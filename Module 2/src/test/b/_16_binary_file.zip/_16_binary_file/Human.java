package _16_binary_file;

import java.io.Serializable;

public class Human implements Serializable {

}
