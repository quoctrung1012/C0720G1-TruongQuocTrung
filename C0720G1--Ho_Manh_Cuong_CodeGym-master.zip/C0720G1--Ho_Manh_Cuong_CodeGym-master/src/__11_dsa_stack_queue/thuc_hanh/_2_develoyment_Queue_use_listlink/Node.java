package __11_dsa_stack_queue.thuc_hanh._2_develoyment_Queue_use_listlink;

public class Node {

    //properties:
    public int key;
    public Node next;

    // method constructor of node:
    public Node(int key) {
          this.key = key;
          this.next = null;
    }
}
