package __11_dsa_stack_queue.bai_tap._2_develoyment_use_listlink_ring;

public class Node {
    public int data;
    public Node link;

    public Node(){

    }
    public Node(int data){
        this.data = data;
    }
}
