package __5_acess_modifiler_static_method_stattic_property.thuc_hanh.__1_acessmpdifier.__protected;

public class A {
    protected void msg(){System.out.println("Hello");}
}
