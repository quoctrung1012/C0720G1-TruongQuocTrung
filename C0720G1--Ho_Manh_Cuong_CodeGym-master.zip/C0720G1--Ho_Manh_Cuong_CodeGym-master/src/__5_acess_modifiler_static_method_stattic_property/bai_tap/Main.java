package __5_acess_modifiler_static_method_stattic_property.bai_tap;

public class Main {
    public static void main(String[] args) {
        Circle circle = new Circle();
        System.out.println("color is : "+circle.getColor());
        System.out.println("Radius is: "+circle.getRadius());
   }
}
