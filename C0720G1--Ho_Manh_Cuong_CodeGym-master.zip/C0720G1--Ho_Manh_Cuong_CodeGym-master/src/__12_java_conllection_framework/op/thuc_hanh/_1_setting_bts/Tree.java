package __12_java_conllection_framework.op.thuc_hanh._1_setting_bts;

public interface Tree<E> {
    public boolean insert(E e);
    public void inorder();
    public int getSize();
}
