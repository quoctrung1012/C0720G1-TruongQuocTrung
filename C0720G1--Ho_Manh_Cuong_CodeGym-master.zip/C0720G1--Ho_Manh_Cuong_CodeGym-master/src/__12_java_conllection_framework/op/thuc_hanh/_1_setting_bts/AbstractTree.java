package __12_java_conllection_framework.op.thuc_hanh._1_setting_bts;

public abstract class AbstractTree<E> implements Tree<E> {
    @Override
    /** Inorder traversal from the root*/
    public void inorder() {

    }
}
