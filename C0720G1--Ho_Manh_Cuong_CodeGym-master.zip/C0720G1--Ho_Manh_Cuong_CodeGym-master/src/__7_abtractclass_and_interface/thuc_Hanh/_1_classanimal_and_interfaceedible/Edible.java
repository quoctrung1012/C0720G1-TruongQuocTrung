package __7_abtractclass_and_interface.thuc_Hanh._1_classanimal_and_interfaceedible;

public interface Edible {
    String howToEat();
}
