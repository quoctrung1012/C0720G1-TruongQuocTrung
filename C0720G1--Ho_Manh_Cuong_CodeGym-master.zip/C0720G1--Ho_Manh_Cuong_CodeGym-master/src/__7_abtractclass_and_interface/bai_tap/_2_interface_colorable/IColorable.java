package __7_abtractclass_and_interface.bai_tap._2_interface_colorable;

public interface IColorable {
     void howToColor();
}
