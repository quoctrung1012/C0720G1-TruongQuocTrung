package __7_abtractclass_and_interface.bai_tap._1_employment_resizeable;

public interface Resizeable {
    void resize(double percent);
}
