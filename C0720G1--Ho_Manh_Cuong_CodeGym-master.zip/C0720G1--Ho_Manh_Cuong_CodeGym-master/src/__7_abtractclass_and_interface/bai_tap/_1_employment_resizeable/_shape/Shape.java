package __7_abtractclass_and_interface.bai_tap._1_employment_resizeable._shape;

import __7_abtractclass_and_interface.bai_tap._1_employment_resizeable.Resizeable;

public abstract class Shape implements Resizeable {
 public abstract double getArea();

}
